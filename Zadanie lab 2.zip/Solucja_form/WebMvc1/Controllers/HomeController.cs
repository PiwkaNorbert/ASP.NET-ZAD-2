﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebMvc1.Models;

namespace WebMvc1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public IActionResult Form1(FormModel model)
        {
            int Year = model.Dob.Year;
            if (((Year % 4 == 0) && (Year % 100 != 0)) || (Year % 400 == 0)) model.LeapYear = true;
            else model.LeapYear = false;
            DateTime a = model.Dob;
            DateTime b = DateTime.Now;
            TimeSpan duration = b - a;
            model.DaysSinceBirth = duration.Days;
            return View(model);
        }      

    }
}
