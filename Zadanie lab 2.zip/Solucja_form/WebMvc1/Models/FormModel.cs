﻿using System.ComponentModel.DataAnnotations;
using System;

namespace WebMvc1.Models
{
    public class FormModel
    {
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Date of Birth")]
       
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        public DateTime Dob { get; set; }
        [Display(Name = "Was your birth year a leap year?")]
        public bool LeapYear { get; set; }
        [Display(Name = "How many days its been since you were born")]
        public int DaysSinceBirth { get; set; }


    }
}
